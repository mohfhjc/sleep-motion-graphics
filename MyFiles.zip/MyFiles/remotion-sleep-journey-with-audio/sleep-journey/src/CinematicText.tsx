import React from "react";
import { spring, useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { loadFont } from "@remotion/google-fonts/Tajawal";

const { fontFamily } = loadFont();

export const CinematicText: React.FC<{ text: string; delay?: number; scaleOut?: boolean }> = ({ text, delay = 0, scaleOut = false }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const moveIn = spring({
    frame: frame - delay,
    fps,
    config: { damping: 12, mass: 0.5, stiffness: 200 },
  });

  const blurValue = interpolate(moveIn, [0, 1], [20, 0], { extrapolateRight: "clamp" });
  const scaleValue = interpolate(moveIn, [0, 1], [3, 1], { extrapolateRight: "clamp" });
  
  const continuousScale = scaleOut ? interpolate(frame, [delay, delay + 120], [1, 1.1]) : 1;

  return (
    <h1
      style={{
        fontFamily,
        fontWeight: 900,
        fontSize: "120px",
        color: "#ffffff",
        textAlign: "center",
        textShadow: "0px 10px 30px rgba(0,0,0,0.8)",
        transform: `scale(${scaleValue * continuousScale}) translateY(${interpolate(moveIn, [0, 1], [100, 0])}px)`,
        filter: `blur(${blurValue}px)`,
        opacity: moveIn,
        margin: 0,
        direction: "rtl",
      }}
    >
      {text}
    </h1>
  );
};
