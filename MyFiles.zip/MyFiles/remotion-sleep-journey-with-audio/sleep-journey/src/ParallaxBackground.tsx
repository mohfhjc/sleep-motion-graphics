import React from "react";
import { AbsoluteFill, Img, interpolate, useCurrentFrame } from "remotion";

export const ParallaxBackground: React.FC<{ src: string; direction?: "zoom-in" | "zoom-out" | "pan-right" }> = ({ src, direction = "zoom-in" }) => {
  const frame = useCurrentFrame();

  let scale = 1;
  let translateX = 0;

  if (direction === "zoom-in") {
    scale = interpolate(frame, [0, 300], [1.1, 1.3], { extrapolateRight: "clamp" });
  } else if (direction === "zoom-out") {
    scale = interpolate(frame, [0, 300], [1.4, 1.1], { extrapolateRight: "clamp" });
  } else if (direction === "pan-right") {
    scale = 1.2;
    translateX = interpolate(frame, [0, 300], [0, 100], { extrapolateRight: "clamp" });
  }

  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      <Img
        src={src}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          transform: `scale(${scale}) translateX(${translateX}px)`,
          opacity: 0.6,
        }}
      />
      <AbsoluteFill
        style={{
          background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.1) 50%, rgba(0,0,0,0.8) 100%)",
        }}
      />
    </AbsoluteFill>
  );
};
