import React from "react";
import { Composition } from "remotion";
import { SleepJourneyMain } from "./SleepJourneyMain";
import "./style.css";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="SleepJourney"
        component={SleepJourneyMain}
        durationInFrames={3600}
        fps={60}
        width={1920}
        height={1080}
      />
    </>
  );
};
