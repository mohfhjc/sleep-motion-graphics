import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { ParallaxBackground } from "./ParallaxBackground";
import { CinematicText } from "./CinematicText";

const ASSETS = {
  brainUniverse: "https://images.unsplash.com/photo-1559757175-5700dde675bc?q=80&w=1920&auto=format&fit=crop",
  sleepDark: "https://images.unsplash.com/photo-1517672651691-24622a91b550?q=80&w=1920&auto=format&fit=crop",
  abstractNeural: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1920&auto=format&fit=crop",
  eyeMacro: "https://images.unsplash.com/photo-1494869042583-f6c911f04b4c?q=80&w=1920&auto=format&fit=crop",
};

export const SleepJourneyMain: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      <Audio src={staticFile("ElevenLabs_2026-10-26T10_59_21_Arafat Almnshid - Social media_pvc_sp100_s50_sb75_v4.mp3")} />

      <Sequence from={0} durationInFrames={180}>
        <ParallaxBackground src={ASSETS.brainUniverse} direction="zoom-in" />
        <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
          <CinematicText text="ماذا لو أخبرتك.." delay={10} scaleOut />
        </AbsoluteFill>
      </Sequence>

      <Sequence from={180} durationInFrames={150}>
        <ParallaxBackground src={ASSETS.abstractNeural} direction="pan-right" />
        <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
          <CinematicText text="أن عقلك لا يتوقف!" delay={0} />
          <div style={{ marginTop: 20 }}>
            <CinematicText text="عندما تنام" delay={30} />
          </div>
        </AbsoluteFill>
      </Sequence>

      <Sequence from={330} durationInFrames={200}>
        <ParallaxBackground src={ASSETS.sleepDark} direction="zoom-out" />
        <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
          <CinematicText text="بل يبدأ رحلة مذهلة.." delay={10} scaleOut />
        </AbsoluteFill>
      </Sequence>

      <Sequence from={530} durationInFrames={180}>
        <AbsoluteFill style={{ backgroundColor: "#0a0a0a", justifyContent: "center", alignItems: "center" }}>
          <video 
            src="https://cdn.pixabay.com/video/2020/05/25/40156-424810793_large.mp4" 
            autoPlay 
            loop 
            style={{ width: "100%", height: "100%", opacity: 0.3, objectFit: "cover" }} 
          />
          <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
            <h1 style={{ color: "#ff3366", fontSize: "180px", margin: 0, fontFamily: "Tajawal", fontWeight: 900 }}>
              لماذا ننام أصلًا؟
            </h1>
          </AbsoluteFill>
        </AbsoluteFill>
      </Sequence>

      <Sequence from={710} durationInFrames={250}>
        <ParallaxBackground src={ASSETS.eyeMacro} direction="zoom-in" />
        <AbsoluteFill style={{ justifyContent: "center", alignItems: "flex-end", paddingBottom: "100px" }}>
          <div style={{ backgroundColor: "rgba(0,0,0,0.7)", padding: "20px 60px", borderRadius: "20px" }}>
            <CinematicText text="مرحلة حركة العين السريعة" delay={20} />
            <h2 style={{ color: "#00e5ff", fontSize: "80px", textAlign: "center", fontFamily: "Tajawal", margin: 0 }}>
              R E M
            </h2>
          </div>
        </AbsoluteFill>
      </Sequence>
    </AbsoluteFill>
  );
};
