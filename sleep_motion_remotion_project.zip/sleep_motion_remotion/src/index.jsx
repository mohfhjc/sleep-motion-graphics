import React from 'react';
import {registerRoot, Composition} from 'remotion';
import {AbsoluteFill, Audio, Sequence, useCurrentFrame, useVideoConfig, interpolate, Easing} from 'remotion';

const scenes = [
 [0,11,'ماذا لو أخبرتك؟','عقلك لا يتوقف عندما تنام','brain','01'],
 [11,22,'رحلة تحدث كل ليلة','ذاكرة • مشاعر • صحة','neural','02'],
 [22,31,'لماذا ننام أصلًا؟','ما الذي يحدث داخل الدماغ؟','question','03'],
 [31,42,'النوم ليس توقفًا','بل إعادة تنظيم للحياة','orbit','04'],
 [42,52,'حين يطرق النعاس','تبدأ الساعة الداخلية بالتغيّر','moon','05'],
 [52,62,'الميلاتونين','إشارة الظلام إلى الجسد','clock','06'],
 [62,72,'المرحلة الأولى','بين اليقظة والنوم','fall','07'],
 [72,82,'انتفاضة مفاجئة؟','تجربة شائعة عند بداية النوم','pulse','08'],
 [82,92,'النوم يصبح أعمق','استجابة أقل للأصوات','waves','09'],
 [92,103,'النوم العميق','إصلاح • تعافٍ • طاقة','cell','10'],
 [103,114,'ذاكرة ومناعة','الجسد يستعيد توازنه','shield','11'],
 [114,125,'مرحلة REM','حركة العين السريعة','eye','12'],
 [125,136,'الدماغ نشط… والجسم ساكن','الأحلام تصبح أكثر وضوحًا','dream','13'],
 [136,147,'سر الأحلام','لماذا نرى عوالم لا وجود لها؟','surreal','14'],
 [147,158,'ذاكرة • عواطف • تجارب','العلم ما زال يبحث عن الإجابة','memory','15'],
 [158,169,'لماذا ننسى أحلامنا؟','قد تتلاشى خلال دقائق','fog','16'],
 [169,180,'النوم يساعدك على التعلّم','المعلومة لا تنتهي بإغلاق الكتاب','book','17'],
 [180,191,'التثبيت يحدث ليلًا','ليلة جيدة قد تصنع فرقًا','synapse','18'],
 [191,202,'ماذا لو حرمت نفسك؟','التعب أول الإشارات','warning','19'],
 [202,213,'تركيز أقل • أخطاء أكثر','استجابة أبطأ وانفعال أسرع','focus','20'],
 [213,224,'صحتك تتأثر','القلب • المناعة • الشهية','health','21'],
 [224,235,'ليست الساعات وحدها','جودة النوم وانتظامه مهمان','quality','22'],
 [235,246,'تنام طويلًا وتستيقظ مرهقًا؟','قد تكون المشكلة في جودة النوم','battery','23'],
 [246,257,'اضبط ساعتك البيولوجية','موعد ثابت للنوم والاستيقاظ','clock','24'],
 [257,268,'خفّف الضوء مساءً','واجعل غرفتك هادئة ومريحة','room','25'],
 [268,279,'انتبه للكافيين','وضوء النهار والنشاط يساعدان','sun','26'],
 [279,290,'كم ساعة تحتاج؟','معظم البالغين: 7 ساعات على الأقل','numbers','27'],
 [290,301,'متى تستشير مختصًا؟','أرق مستمر • شخير شديد • نعاس مفرط','medical','28'],
 [301,312,'كل ليلة فرصة جديدة','دماغك وجسمك يعملان من أجلك','brain','29'],
 [312,323,'النوم ليس وقتًا ضائعًا','إنه استثمار في صحتك ومستقبلك','investment','30'],
 [323,334,'والآن… سؤال لك','هل تتذكر أحلامك؟','question','31'],
 [334,344,'أم تختفي بعد لحظات؟','شاركنا إجابتك في التعليقات','comment','32'],
 [344,354.116,'اكتشف المزيد من الأسرار','تابع القناة للمزيد','end','33'],
];
const palettes = [ ['#071126','#00e5ff','#8768ff'], ['#080d24','#4df7d8','#7a5cff'], ['#10091f','#ffb547','#ff477e'], ['#050b18','#9a7bff','#42d9ff'] ];

function SceneVisual({type, frame, accent, accent2}) {
 const t=frame/30;
 const common={position:'absolute',inset:0,overflow:'hidden'};
 const rings=Array.from({length:7},(_,i)=><div key={i} style={{position:'absolute',left:`${50+Math.sin(t*.25+i)*8}%`,top:`${50+Math.cos(t*.2+i)*7}%`,width:100+i*115,height:100+i*115,border:`1px solid ${accent}${['55','35','25','20','15','10','08'][i]}`,borderRadius:'50%',transform:`translate(-50%,-50%) rotate(${t*10+i*15}deg) scale(${1+Math.sin(t+i)*.04})`}}/>);
 const dots=Array.from({length:72},(_,i)=><i key={i} style={{position:'absolute',left:`${(i*37)%100}%`,top:`${(i*61)%100}%`,width:i%7===0?4:2,height:i%7===0?4:2,borderRadius:'50%',background:i%3?accent:accent2,opacity:.22+((i%5)/10),transform:`translateY(${Math.sin(t+i)*15}px)`}}/>);
 const icon = {
 brain:<svg viewBox="0 0 400 400"><defs><radialGradient id="brainG"><stop stopColor={accent} stopOpacity=".9"/><stop offset="1" stopColor={accent2} stopOpacity=".1"/></radialGradient></defs><path d="M200 60 C130 20 70 80 90 135 C45 165 75 230 112 240 C90 300 145 340 190 315 L200 300 L210 315 C260 340 310 300 288 240 C325 230 355 165 310 135 C330 80 270 20 200 60Z" fill="url(#brainG)" stroke={accent} strokeWidth="3"/><path d="M200 60V300 M120 100Q170 120 155 170T190 240 M280 100Q230 120 245 170T210 240 M95 170Q140 180 130 220 M305 170Q260 180 270 220" fill="none" stroke={accent2} strokeWidth="3" strokeLinecap="round"/><circle cx="200" cy="190" r="12" fill="#fff"/></svg>,
 eye:<svg viewBox="0 0 400 250"><path d="M25 125 Q200 -20 375 125 Q200 270 25 125Z" fill={`${accent}20`} stroke={accent} strokeWidth="4"/><circle cx="200" cy="125" r="62" fill={`${accent2}66`} stroke={accent2} strokeWidth="4"/><circle cx="200" cy="125" r="25" fill={accent}/><circle cx="220" cy="105" r="10" fill="#fff"/></svg>,
 shield:<svg viewBox="0 0 300 350"><path d="M150 15 L270 60 V155 Q260 260 150 325 Q40 260 30 155 V60Z" fill={`${accent}18`} stroke={accent} strokeWidth="5"/><path d="M90 170 L130 210 L215 120" fill="none" stroke={accent2} strokeWidth="13" strokeLinecap="round" strokeLinejoin="round"/></svg>,
 clock:<svg viewBox="0 0 300 300"><circle cx="150" cy="150" r="115" fill="none" stroke={accent} strokeWidth="5"/><circle cx="150" cy="150" r="90" fill={`${accent2}16`} stroke={accent2} strokeWidth="2" strokeDasharray="5 12"/><path d="M150 70V150L210 180" fill="none" stroke="#fff" strokeWidth="7" strokeLinecap="round"/><circle cx="150" cy="150" r="9" fill={accent}/></svg>,
 };
 return <div style={common}>
  <div style={{position:'absolute',inset:0,background:`radial-gradient(ellipse at ${type==='sun'?'50% 25%':'65% 50%'}, ${accent}25 0%, transparent 48%), linear-gradient(125deg,#050814 0%,#0b1330 55%,#050814 100%)`}}/>
  <div style={{position:'absolute',inset:0,opacity:.8}}>{rings}{dots}</div>
  <div style={{position:'absolute',right:'8%',top:'12%',width:'42%',height:'76%',display:'flex',alignItems:'center',justifyContent:'center',filter:`drop-shadow(0 0 32px ${accent}55)`,transform:`translateY(${Math.sin(t*.7)*12}px) rotate(${Math.sin(t*.25)*3}deg) scale(${1+Math.sin(t*.55)*.035})`}}>
   {icon[type] || <svg viewBox="0 0 400 400"><circle cx="200" cy="200" r="130" fill={`${accent}10`} stroke={accent} strokeWidth="2"/><circle cx="200" cy="200" r="95" fill="none" stroke={accent2} strokeWidth="2" strokeDasharray="9 8"/><path d="M70 220 C120 100 180 300 235 170 S320 120 340 190" fill="none" stroke={accent} strokeWidth="5"/><circle cx="235" cy="170" r="12" fill="#fff"/><path d="M200 40V80 M200 320V360 M40 200H80 M320 200H360" stroke={accent2} strokeWidth="4"/></svg>}
  </div>
  <div style={{position:'absolute',left:'7%',top:'15%',width:'42%',height:'70%',borderLeft:`1px solid ${accent}55`,borderTop:`1px solid ${accent}55`,borderBottom:`1px solid ${accent}20`}}/>
  <div style={{position:'absolute',left:'7%',top:'15%',fontSize:15,letterSpacing:5,color:accent,fontWeight:800}}>SLEEP / LAB <span style={{color:'#fff',opacity:.5}}>— {String(Math.floor(t)).padStart(2,'0')}:{String(frame%30).padStart(2,'0')}</span></div>
  <div style={{position:'absolute',left:'7%',bottom:'13%',display:'flex',gap:8,alignItems:'center'}}>{Array.from({length:18},(_,i)=><span key={i} style={{width:3,height:10+(i%5)*7,background:i<Math.floor((frame/30)%18)?accent:accent+'35',transform:`scaleY(${.7+Math.sin(t+i)*.3})`}}/>)}</div>
 </div>
}
function Scene({data,index}){
 const frame=useCurrentFrame(); const {fps}=useVideoConfig();
 const [start,end,title,sub,type,num]=data; const local=frame/fps;
 const p=interpolate(local,[0,0.6,Math.max(.7,end-start-.5),end-start],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.out(Easing.cubic)});
 const zoom=interpolate(local,[0,end-start],[1.12,1.0],{extrapolateRight:'clamp'});
 const [bg,accent,accent2]=palettes[index%palettes.length];
 return <AbsoluteFill style={{background:bg,opacity:p,transform:`scale(${zoom})`,fontFamily:'Arial, Tahoma, sans-serif',direction:'rtl'}}>
  <SceneVisual type={type} frame={frame} accent={accent} accent2={accent2}/>
  <div style={{position:'absolute',left:'7%',top:'28%',width:'48%',color:'#fff',textAlign:'right',transform:`translateX(${(1-p)*70}px)`}}>
   <div style={{fontSize:19,fontWeight:900,letterSpacing:3,color:accent,marginBottom:24,opacity:.95}}>الفصل {num} <span style={{color:'#ffffff77'}}> / العقل أثناء النوم</span></div>
   <div style={{fontSize:title.length>25?43:58,fontWeight:950,lineHeight:1.22,textShadow:`0 0 35px ${accent}40`,marginBottom:22}}>{title}</div>
   <div style={{fontSize:26,color:'#dbe6ff',lineHeight:1.6,fontWeight:500,borderRight:`4px solid ${accent}`,paddingRight:18}}>{sub}</div>
  </div>
  <div style={{position:'absolute',left:0,right:0,bottom:0,height:5,background:'#ffffff18'}}><div style={{height:'100%',width:`${(frame/(fps*(end-start)))*100}%`,background:accent,boxShadow:`0 0 18px ${accent}`}}/></div>
  <div style={{position:'absolute',right:35,bottom:26,fontSize:13,letterSpacing:3,color:'#ffffff77'}}>MIRROR MIRAGE  •  MIND / BODY</div>
 </AbsoluteFill>
}
function Main(){const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#050814'}}><Audio src={require('../public/voice.mp3')} volume={1}/>{scenes.map((s,i)=><Sequence key={s[5]} from={Math.round(s[0]*fps)} durationInFrames={Math.round((s[1]-s[0])*fps)}><Scene data={s} index={i}/></Sequence>)}</AbsoluteFill>}
function Root(){return <Composition id="SleepMotion" component={Main} durationInFrames={Math.ceil(354.116*30)} fps={30} width={1920} height={1080}/>}
registerRoot(Root);
