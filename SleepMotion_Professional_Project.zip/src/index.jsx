import React from 'react';
import {registerRoot, Composition} from 'remotion';
import {AbsoluteFill, Audio, Sequence, useCurrentFrame, useVideoConfig, interpolate, Easing, staticFile} from 'remotion';

const scenes = [
 [0,11,'ماذا لو أخبرتك؟','عقلك لا يتوقف عندما تنام','brain','01'],
 [11,22,'رحلة تحدث كل ليلة','ذاكرة • مشاعر • صحة','neural','02'],
 [22,31,'لماذا ننام أصلًا؟','ما الذي يحدث داخل الدماغ؟','question','03'],
 [31,42,'النوم ليس توقفًا','بل إعادة تنظيم للحياة','orbit','04'],
 [42,52,'حين يطرق النعاس','تبدأ الساعة الداخلية بالتغيّر','moon','05'],
 [52,62,'الميلاتونين','إشارة الظلام إلى الجسد','clock','06'],
 [62,72,'المرحلة الأولى','بين اليقظة والنوم','fall','07'],
 [72,82,'انتفاضة مفاجئة؟','تجربة شائعة عند بداية النوم','pulse','08'],
 [82,92,'النوم يصبح أعمق','استجابة أقل للأصوات','waves','09'],
 [92,103,'النوم العميق','إصلاح • تعافٍ • طاقة','cell','10'],
 [103,114,'ذاكرة ومناعة','الجسد يستعيد توازنه','shield','11'],
 [114,125,'مرحلة REM','حركة العين السريعة','eye','12'],
 [125,136,'الدماغ نشط… والجسم ساكن','الأحلام تصبح أكثر وضوحًا','dream','13'],
 [136,147,'سر الأحلام','لماذا نرى عوالم لا وجود لها؟','surreal','14'],
 [147,158,'ذاكرة • عواطف • تجارب','العلم ما زال يبحث عن الإجابة','memory','15'],
 [158,169,'لماذا ننسى أحلامنا؟','قد تتلاشى خلال دقائق','fog','16'],
 [169,180,'النوم يساعدك على التعلّم','المعلومة لا تنتهي بإغلاق الكتاب','book','17'],
 [180,191,'التثبيت يحدث ليلًا','ليلة جيدة قد تصنع فرقًا','synapse','18'],
 [191,202,'ماذا لو حرمت نفسك؟','التعب أول الإشارات','warning','19'],
 [202,213,'تركيز أقل • أخطاء أكثر','استجابة أبطأ وانفعال أسرع','focus','20'],
 [213,224,'صحتك تتأثر','القلب • المناعة • الشهية','health','21'],
 [224,235,'ليست الساعات وحدها','جودة النوم وانتظامه مهمان','quality','22'],
 [235,246,'تنام طويلًا وتستيقظ مرهقًا؟','قد تكون المشكلة في جودة النوم','battery','23'],
 [246,257,'اضبط ساعتك البيولوجية','موعد ثابت للنوم والاستيقاظ','clock','24'],
 [257,268,'خفّف الضوء مساءً','واجعل غرفتك هادئة ومريحة','room','25'],
 [268,279,'انتبه للكافيين','وضوء النهار والنشاط يساعدان','sun','26'],
 [279,290,'كم ساعة تحتاج؟','معظم البالغين: 7 ساعات على الأقل','numbers','27'],
 [290,301,'متى تستشير مختصًا؟','أرق مستمر • شخير شديد • نعاس مفرط','medical','28'],
 [301,312,'كل ليلة فرصة جديدة','دماغك وجسمك يعملان من أجلك','brain','29'],
 [312,323,'النوم ليس وقتًا ضائعًا','إنه استثمار في صحتك ومستقبلك','investment','30'],
 [323,334,'والآن… سؤال لك','هل تتذكر أحلامك؟','question','31'],
 [334,344,'أم تختفي بعد لحظات؟','شاركنا إجابتك في التعليقات','comment','32'],
 [344,354.116,'اكتشف المزيد من الأسرار','تابع القناة للمزيد','end','33'],
];
const palettes = [ ['#071126','#00e5ff','#8768ff'], ['#080d24','#4df7d8','#7a5cff'], ['#10091f','#ffb547','#ff477e'], ['#050b18','#9a7bff','#42d9ff'] ];

function SceneVisual({type, frame, accent, accent2}) {
 const t=frame/30;
 const common={position:'absolute',inset:0,overflow:'hidden'};
 const rings=Array.from({length:7},(_,i)=><div key={i} style={{position:'absolute',left:`${50+Math.sin(t*.25+i)*8}%`,top:`${50+Math.cos(t*.2+i)*7}%`,width:100+i*115,height:100+i*115,border:`1px solid ${accent}${['55','35','25','20','15','10','08'][i]}`,borderRadius:'50%',transform:`translate(-50%,-50%) rotate(${t*10+i*15}deg) scale(${1+Math.sin(t+i)*.04})`}}/>);
 const dots=Array.from({length:72},(_,i)=><i key={i} style={{position:'absolute',left:`${(i*37)%100}%`,top:`${(i*61)%100}%`,width:i%7===0?4:2,height:i%7===0?4:2,borderRadius:'50%',background:i%3?accent:accent2,opacity:.22+((i%5)/10),transform:`translateY(${Math.sin(t+i)*15}px)`}}/>);
 const icon = {
 moon:<svg viewBox="0 0 300 300"><defs><linearGradient id="moonG" x1="0" x2="1" y1="0" y2="1"><stop stopColor={accent}/><stop offset="1" stopColor={accent2}/></linearGradient></defs><path d="M215 35A115 115 0 1 0 265 220A92 92 0 0 1 215 35Z" fill="url(#moonG)" stroke="#fff" strokeOpacity=".65" strokeWidth="2"/><circle cx="85" cy="70" r="4" fill="#fff"/><circle cx="45" cy="150" r="3" fill={accent}/><path d="M55 225l8 16 17 3-13 12 3 17-15-8-15 8 3-17-13-12 17-3z" fill={accent2}/></svg>,
 waves:<svg viewBox="0 0 420 260">{Array.from({length:7},(_,i)=><path key={i} d={`M15 ${130+i*2} ${Array.from({length:15},(_,j)=>`L${25+j*27} ${130+Math.sin(j*.8+i*.55)*((i+1)*10)}`).join(" ")}`} fill="none" stroke={i%2?accent:accent2} strokeWidth={i===3?4:2} opacity={.28+i*.09} strokeLinecap="round"/>)}<circle cx="210" cy="130" r="10" fill="#fff"/></svg>,
 neural:<svg viewBox="0 0 400 400">{Array.from({length:22},(_,i)=>{const x=45+(i*73)%310,y=45+(i*127)%310;return <g key={i}><line x1={x} y1={y} x2={200+Math.sin(i*2)*100} y2={200+Math.cos(i*1.7)*100} stroke={accent} strokeOpacity=".35" strokeWidth="2"/><circle cx={x} cy={y} r={i%4===0?7:4} fill={i%3?accent:accent2}/></g>})}<circle cx="200" cy="200" r="42" fill={`${accent2}35`} stroke={accent2} strokeWidth="3"/><circle cx="200" cy="200" r="12" fill="#fff"/></svg>,
 orbit:<svg viewBox="0 0 400 400"><circle cx="200" cy="200" r="28" fill={accent}/>{[70,115,160].map((r,i)=><ellipse key={r} cx="200" cy="200" rx={r} ry={r*.43} fill="none" stroke={i%2?accent:accent2} strokeWidth="3" transform={`rotate(${i*55} 200 200)`}/>)}<circle cx="310" cy="200" r="10" fill="#fff"/><circle cx="140" cy="95" r="8" fill={accent2}/></svg>,
 pulse:<svg viewBox="0 0 420 260"><path d="M10 130H90L120 80L150 185L185 45L225 210L260 105L285 130H410" fill="none" stroke={accent} strokeWidth="6" strokeLinejoin="round" strokeLinecap="round"/><path d="M10 150H410" stroke={accent2} strokeOpacity=".25" strokeWidth="2"/><circle cx="185" cy="45" r="10" fill="#fff"/></svg>,
 cell:<svg viewBox="0 0 400 400"><path d="M200 45 C280 40 350 115 340 200 S280 350 195 350 S45 280 55 195 S120 50 200 45Z" fill={`${accent}20`} stroke={accent} strokeWidth="4"/><path d="M120 135 Q180 85 220 145 T285 205 T190 275 T105 210Z" fill={`${accent2}35`} stroke={accent2} strokeWidth="3"/>{Array.from({length:18},(_,i)=><circle key={i} cx={95+(i*43)%210} cy={100+(i*67)%200} r={i%4===0?7:3} fill={i%2?accent:accent2}/>)}</svg>,
 dream:<svg viewBox="0 0 400 400"><path d="M65 260 C15 185 95 110 150 145 C170 55 295 80 290 165 C370 205 320 300 250 285 C200 355 105 330 65 260Z" fill={`${accent}20`} stroke={accent} strokeWidth="3"/><path d="M100 230 Q150 150 200 230 T300 220" fill="none" stroke={accent2} strokeWidth="5"/><circle cx="150" cy="180" r="12" fill="#fff"/><circle cx="265" cy="245" r="8" fill={accent2}/></svg>,
 book:<svg viewBox="0 0 400 330"><path d="M200 75 Q115 30 40 65V270Q125 235 200 285Q275 235 360 270V65Q285 30 200 75Z" fill={`${accent}20`} stroke={accent} strokeWidth="4"/><path d="M200 78V282 M65 105Q125 85 165 115 M65 145Q125 125 165 155 M235 115Q280 85 335 105 M235 155Q280 125 335 145" fill="none" stroke={accent2} strokeWidth="4" strokeLinecap="round"/></svg>,
 warning:<svg viewBox="0 0 360 330"><path d="M180 30L335 295H25Z" fill={`${accent}20`} stroke={accent} strokeWidth="5" strokeLinejoin="round"/><path d="M180 110V205" stroke="#fff" strokeWidth="14" strokeLinecap="round"/><circle cx="180" cy="245" r="9" fill={accent2}/></svg>,
 battery:<svg viewBox="0 0 400 240"><rect x="35" y="65" width="300" height="110" rx="18" fill={`${accent}12`} stroke={accent} strokeWidth="5"/><rect x="340" y="100" width="25" height="40" rx="6" fill={accent}/><rect x="50" y="80" width="135" height="80" rx="8" fill={accent2}/><path d="M205 95l-20 30h25l-12 22 40-38h-27l12-14Z" fill="#fff"/></svg>,
 sun:<svg viewBox="0 0 400 400"><circle cx="200" cy="200" r="75" fill={accent} fillOpacity=".8"/>{Array.from({length:12},(_,i)=><line key={i} x1="200" y1="80" x2="200" y2="35" stroke={accent2} strokeWidth="6" strokeLinecap="round" transform={`rotate(${i*30} 200 200)`}/>)}<circle cx="175" cy="180" r="9" fill="#fff"/><circle cx="225" cy="180" r="9" fill="#fff"/><path d="M170 220Q200 245 230 220" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round"/></svg>,
 numbers:<svg viewBox="0 0 400 300"><text x="200" y="170" fill={accent} fontSize="140" fontWeight="900" textAnchor="middle">7–9</text><text x="200" y="225" fill="#fff" fontSize="27" textAnchor="middle">ساعات نوم</text><path d="M55 250H345" stroke={accent2} strokeWidth="4" strokeLinecap="round"/></svg>,
 medical:<svg viewBox="0 0 300 360"><rect x="45" y="45" width="210" height="270" rx="28" fill={`${accent}15`} stroke={accent} strokeWidth="4"/><path d="M150 95V265 M65 180H235" stroke={accent2} strokeWidth="24" strokeLinecap="round"/><circle cx="150" cy="180" r="15" fill="#fff"/></svg>,
 memory:<svg viewBox="0 0 400 400"><path d="M200 70C120 20 60 90 90 150C40 210 100 270 145 255C155 320 245 320 255 255C300 270 360 210 310 150C340 90 280 20 200 70Z" fill={`${accent}20`} stroke={accent} strokeWidth="4"/><path d="M120 145Q160 110 190 155T260 145 M115 205Q160 175 195 215T275 205" fill="none" stroke={accent2} strokeWidth="5" strokeLinecap="round"/><circle cx="200" cy="185" r="10" fill="#fff"/></svg>,
 brain:<svg viewBox="0 0 400 400"><defs><radialGradient id="brainG"><stop stopColor={accent} stopOpacity=".9"/><stop offset="1" stopColor={accent2} stopOpacity=".1"/></radialGradient></defs><path d="M200 60 C130 20 70 80 90 135 C45 165 75 230 112 240 C90 300 145 340 190 315 L200 300 L210 315 C260 340 310 300 288 240 C325 230 355 165 310 135 C330 80 270 20 200 60Z" fill="url(#brainG)" stroke={accent} strokeWidth="3"/><path d="M200 60V300 M120 100Q170 120 155 170T190 240 M280 100Q230 120 245 170T210 240 M95 170Q140 180 130 220 M305 170Q260 180 270 220" fill="none" stroke={accent2} strokeWidth="3" strokeLinecap="round"/><circle cx="200" cy="190" r="12" fill="#fff"/></svg>,
 eye:<svg viewBox="0 0 400 250"><path d="M25 125 Q200 -20 375 125 Q200 270 25 125Z" fill={`${accent}20`} stroke={accent} strokeWidth="4"/><circle cx="200" cy="125" r="62" fill={`${accent2}66`} stroke={accent2} strokeWidth="4"/><circle cx="200" cy="125" r="25" fill={accent}/><circle cx="220" cy="105" r="10" fill="#fff"/></svg>,
 shield:<svg viewBox="0 0 300 350"><path d="M150 15 L270 60 V155 Q260 260 150 325 Q40 260 30 155 V60Z" fill={`${accent}18`} stroke={accent} strokeWidth="5"/><path d="M90 170 L130 210 L215 120" fill="none" stroke={accent2} strokeWidth="13" strokeLinecap="round" strokeLinejoin="round"/></svg>,
 clock:<svg viewBox="0 0 300 300"><circle cx="150" cy="150" r="115" fill="none" stroke={accent} strokeWidth="5"/><circle cx="150" cy="150" r="90" fill={`${accent2}16`} stroke={accent2} strokeWidth="2" strokeDasharray="5 12"/><path d="M150 70V150L210 180" fill="none" stroke="#fff" strokeWidth="7" strokeLinecap="round"/><circle cx="150" cy="150" r="9" fill={accent}/></svg>,
 };
 return <div style={common}>
  <div style={{position:'absolute',inset:0,background:`radial-gradient(ellipse at ${type==='sun'?'50% 25%':'65% 50%'}, ${accent}30 0%, transparent 48%), linear-gradient(125deg,#030611 0%,#0b1330 55%,#030611 100%)`}}/>
  <div style={{position:'absolute',inset:0,backgroundImage:`linear-gradient(${accent}0c 1px,transparent 1px),linear-gradient(90deg,${accent}0c 1px,transparent 1px)`,backgroundSize:'56px 56px',opacity:.5,transform:`translate(${Math.sin(t*.15)*18}px,${Math.cos(t*.12)*14}px)`}}/>
  <div style={{position:'absolute',left:0,right:0,height:'18%',top:`${((frame*0.35)%125)-15}%`,background:`linear-gradient(180deg,transparent,${accent}0b,transparent)`,pointerEvents:'none'}}/>
  <div style={{position:'absolute',inset:0,opacity:.8}}>{rings}{dots}</div>
  <div style={{position:'absolute',right:'8%',top:'12%',width:'42%',height:'76%',display:'flex',alignItems:'center',justifyContent:'center',filter:`drop-shadow(0 0 32px ${accent}55)`,transform:`translateY(${Math.sin(t*.7)*12}px) rotate(${Math.sin(t*.25)*3}deg) scale(${1+Math.sin(t*.55)*.035})`}}>
   {icon[type] || <svg viewBox="0 0 400 400"><circle cx="200" cy="200" r="130" fill={`${accent}10`} stroke={accent} strokeWidth="2"/><circle cx="200" cy="200" r="95" fill="none" stroke={accent2} strokeWidth="2" strokeDasharray="9 8"/><path d="M70 220 C120 100 180 300 235 170 S320 120 340 190" fill="none" stroke={accent} strokeWidth="5"/><circle cx="235" cy="170" r="12" fill="#fff"/><path d="M200 40V80 M200 320V360 M40 200H80 M320 200H360" stroke={accent2} strokeWidth="4"/></svg>}
  </div>
  <div style={{position:'absolute',left:'7%',top:'15%',width:'42%',height:'70%',borderLeft:`1px solid ${accent}55`,borderTop:`1px solid ${accent}55`,borderBottom:`1px solid ${accent}20`}}/>
  <div style={{position:'absolute',left:'7%',top:'15%',fontSize:15,letterSpacing:5,color:accent,fontWeight:800}}>SLEEP / LAB <span style={{color:'#fff',opacity:.5}}>— {String(Math.floor(t)).padStart(2,'0')}:{String(frame%30).padStart(2,'0')}</span></div>
  <div style={{position:'absolute',left:'7%',bottom:'13%',display:'flex',gap:8,alignItems:'center'}}>{Array.from({length:18},(_,i)=><span key={i} style={{width:3,height:10+(i%5)*7,background:i<Math.floor((frame/30)%18)?accent:accent+'35',transform:`scaleY(${.7+Math.sin(t+i)*.3})`}}/>)}</div>
 </div>
}
function Scene({data,index}){
 const frame=useCurrentFrame(); const {fps}=useVideoConfig();
 const [start,end,title,sub,type,num]=data; const local=frame/fps;
 const p=interpolate(local,[0,0.6,Math.max(.7,end-start-.5),end-start],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.out(Easing.cubic)});
 const zoom=interpolate(local,[0,end-start],[1.12,1.0],{extrapolateRight:'clamp'});
 const [bg,accent,accent2]=palettes[index%palettes.length];
 return <AbsoluteFill style={{background:bg,opacity:p,transform:`scale(${zoom})`,fontFamily:'Arial, Tahoma, sans-serif',direction:'rtl'}}>
  <SceneVisual type={type} frame={frame} accent={accent} accent2={accent2}/>
  <div style={{position:'absolute',left:'7%',top:'28%',width:'48%',color:'#fff',textAlign:'right',transform:`translateX(${(1-p)*70}px)`}}>
   <div style={{fontSize:19,fontWeight:900,letterSpacing:3,color:accent,marginBottom:24,opacity:.95}}>الفصل {num} <span style={{color:'#ffffff77'}}> / العقل أثناء النوم</span></div>
   <div style={{fontSize:title.length>25?43:58,fontWeight:950,lineHeight:1.22,textShadow:`0 0 35px ${accent}40`,marginBottom:22}}>{title}</div>
   <div style={{fontSize:26,color:'#dbe6ff',lineHeight:1.6,fontWeight:500,borderRight:`4px solid ${accent}`,paddingRight:18}}>{sub}</div>
  </div>
  <div style={{position:'absolute',left:0,right:0,bottom:0,height:5,background:'#ffffff18'}}><div style={{height:'100%',width:`${(frame/(fps*(end-start)))*100}%`,background:accent,boxShadow:`0 0 18px ${accent}`}}/></div>
  <div style={{position:'absolute',right:35,bottom:26,fontSize:13,letterSpacing:3,color:'#ffffff77'}}>MIRROR MIRAGE  •  MIND / BODY</div>
 </AbsoluteFill>
}
function Main(){const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#050814'}}><Audio src={staticFile("voice.mp3")} volume={1}/>{scenes.map((s,i)=><Sequence key={s[5]} from={Math.round(s[0]*fps)} durationInFrames={Math.round((s[1]-s[0])*fps)}><Scene data={s} index={i}/></Sequence>)}</AbsoluteFill>}
function Root(){return <Composition id="SleepMotion" component={Main} durationInFrames={Math.ceil(354.116*30)} fps={30} width={1920} height={1080}/>}
registerRoot(Root);
