# مشروع Sleep Motion — النسخة المطوّرة

مشروع Remotion لفيديو وثائقي عربي عن النوم والدماغ، بنسبة 16:9 ودقة 1920×1080 ومعدل 30 إطارًا/ثانية.

## التشغيل محليًا
1. ثبّت Node.js.
2. نفّذ `npm install`.
3. نفّذ `npm run render`.

## GitHub Actions
ضع ملف الـWorkflow في المستودع تحت `.github/workflows/render.yml`، ثم شغّله من تبويب Actions. سيرفع الفيديو النهائي كـArtifact باسم `sleep-motion-video`.

الملف الصوتي المستخدم هو `public/voice.mp3`. لا تحذف هذا الملف ولا تغيّر اسمه إلا إذا عدّلت مساره في الكود.
