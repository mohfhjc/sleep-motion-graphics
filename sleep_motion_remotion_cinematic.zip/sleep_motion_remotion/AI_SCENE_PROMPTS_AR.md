# حزمة المشاهد السينمائية بالذكاء الاصطناعي — Sleep Motion / Mirror Mirage

هذه البرومبتات مخصصة لتوليد لقطات فيديو قصيرة تُستخدم كخلفيات سينمائية فوقها الرسوم العلمية والعناوين العربية الموجودة في مشروع Remotion. وللحفاظ على جودة الإخراج، ولّد كل لقطة منفصلة بنسبة 16:9 وبدون نصوص أو شعارات أو موسيقى. اترك مساحة هادئة في الجانب الأيسر للعناوين العربية، واجعل العنصر البصري الرئيسي في الجانب الأيمن.

## إعدادات موحدة لكل اللقطات
- Aspect ratio: 16:9
- Duration: 5–8 seconds per clip
- Look: premium science documentary, cinematic realism, deep midnight navy, cyan and violet highlights, controlled volumetric lighting, realistic materials, subtle film grain, slow deliberate camera movement
- Audio: no music, no dialogue, no sound effects
- Avoid: text, captions, logos, watermarks, fast cuts, flicker, distorted anatomy, gore, fantasy cartoon style
- Motion: one continuous shot, smooth movement, no abrupt camera shake, loop-friendly ending when possible

## 1. افتتاحية: العقل أثناء النوم
**Prompt (English):**
A premium cinematic science documentary shot of a sleeping adult lying peacefully in a dark modern bedroom at night, shown in tasteful side profile, cool moonlight entering through sheer curtains. A subtle translucent visualization of a human brain glows softly in cyan and violet above the head, with delicate neural pulses travelling through realistic branching pathways. Deep navy shadows, realistic skin and fabric, physically plausible lighting, volumetric haze, shallow depth of field, slow dolly-in, elegant and restrained, photorealistic, 16:9. Keep the left 42 percent dark and uncluttered for Arabic titles. No text, no logos, no music.

## 2. الشبكات العصبية والذاكرة
**Prompt (English):**
Extreme macro cinematic visualization of a biologically inspired neural network suspended in a dark scientific space, thousands of delicate synaptic branches and luminous particles, cyan electrical impulses travelling from node to node, violet depth lights, realistic microscopic textures, elegant scientific documentary aesthetic rather than fantasy, slow camera orbit and gentle parallax, high contrast but detailed shadows, 16:9. Keep the left side dark and clear for title overlays. No text, no labels, no logos, no music.

## 3. الساعة البيولوجية والميلاتونين
**Prompt (English):**
Cinematic macro shot of a bedroom transitioning from blue twilight to deep night through a window, a realistic analog clock softly out of focus in the foreground, subtle particles of cool moonlight drifting in the air, restrained scientific visualization of a circadian rhythm represented by a thin glowing circular arc in the background, deep navy, teal and muted violet palette, smooth lateral camera slide, premium documentary realism, 16:9. Leave the left side uncluttered. No text, no logos, no music.

## 4. النوم العميق واستعادة الجسد
**Prompt (English):**
Sophisticated medical-science visualization of human cells and tissue in a calm dark microscopic environment, translucent cellular membranes, gentle cyan and amber molecular particles moving slowly between structures, a sense of restoration and biological maintenance, physically inspired details, cinematic macro lens, soft volumetric beams, no frightening imagery, no exaggerated fantasy effects, slow smooth camera push, 16:9. Reserve dark negative space on the left for Arabic typography. No text, no labels, no logos, no music.

## 5. مرحلة الأحلام REM
**Prompt (English):**
A beautiful surreal-yet-photorealistic science documentary visualization of a dreamscape forming from drifting fragments of memory: a quiet ocean horizon, floating translucent geometric reflections, distant clouds and soft particles, subtle neural light filaments connecting the fragments. Sophisticated, contemplative, mysterious but not horror, midnight blue with cyan and violet highlights, slow continuous forward camera movement, realistic cinematic atmosphere, 16:9. Keep the left 42 percent dark and visually simple for Arabic titles. No text, no logos, no music.

## 6. الحرمان من النوم والتركيز
**Prompt (English):**
Cinematic realistic close-up of a tired adult sitting at a desk before dawn, eyes heavy and posture slightly slumped, computer screen softly blurred and not readable, cool early-morning window light, subtle double-layered reflections suggesting reduced focus without visual distortion, natural skin texture, restrained emotional tone, slow gentle camera push-in, premium health documentary, deep blue shadows and soft neutral highlights, 16:9. Leave the left side dark for title text. No readable text, no logos, no music.

## 7. عادات النوم الصحية
**Prompt (English):**
Premium lifestyle science documentary shot of a peaceful minimalist bedroom prepared for sleep: neatly made bed, warm bedside lamp being switched off, cool moonlight from the window, curtains moving very gently, calm uncluttered composition, realistic materials and natural shadows, slow smooth camera slide, muted navy and soft amber color grade, photorealistic, 16:9. Keep left side uncluttered for Arabic titles. No text, no logos, no music.

## 8. الخاتمة: استيقاظ وبداية جديدة
**Prompt (English):**
Cinematic sunrise entering a quiet bedroom, a person waking refreshed in silhouette, warm sunlight gently spreading across cool blue shadows, dust motes glowing in the light, hopeful but understated science-documentary tone, slow dolly backward, realistic lens behavior, elegant navy-to-gold color transition, 16:9. Leave negative space on the left for Arabic closing title and channel branding. No text, no logos, no music.

## طريقة الدمج في المشروع
1. ولّد اللقطات منفصلة من أداة الفيديو التي تستخدمها، مع إعدادات موحدة.
2. لا تضع كتابة عربية داخل الفيديو المولّد؛ العناوين العربية في المشروع ستبقى أوضح وأسهل في التعديل.
3. احتفظ بالملفات بأسماء `01-opening.mp4` إلى `08-ending.mp4`.
4. ارفعها إلى مجلد `public/scenes/` بعد تجهيز نسخة دمج تدعم ملفات المشاهد؛ لا تضعها في جذر المستودع كي لا تختلط بملفات الكود.
5. احتفظ بالتعليق الصوتي الأصلي وحده في المسار الصوتي؛ البرومبتات تطلب عدم إنشاء موسيقى أو حوار.

**تنبيه:** هذه الحزمة تتضمن برومبتات إنتاج اللقطات وليست ملفات فيديو مولّدة بحد ذاتها. النسخة الحالية تعرض رسومًا متحركة مولّدة برمجيًا، ولا تستورد لقطات AI خارجية تلقائيًا حتى تُضاف ملفات الفيديو ويُفعّل دمجها في الكود.
