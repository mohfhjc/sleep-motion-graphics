import React from 'react';
import {registerRoot, Composition, AbsoluteFill, Audio, Sequence, useCurrentFrame, useVideoConfig, interpolate, Easing, staticFile} from 'remotion';

const FPS = 30;
const DURATION = 354.116;
const scenes = [
 [0,11,'ماذا لو أخبرتك؟','عقلك لا يتوقف عندما تنام','brain','01','ما وراء النوم'],
 [11,22,'رحلة تحدث كل ليلة','ذاكرة • مشاعر • صحة','neural','02','داخل العقل'],
 [22,31,'لماذا ننام أصلًا؟','ما الذي يحدث داخل الدماغ؟','question','03','السؤال الكبير'],
 [31,42,'النوم ليس توقفًا','بل إعادة تنظيم للحياة','orbit','04','نشاط لا يتوقف'],
 [42,52,'حين يطرق النعاس','تبدأ الساعة الداخلية بالتغيّر','moon','05','الإيقاع الحيوي'],
 [52,62,'الميلاتونين','إشارة الظلام إلى الجسد','clock','06','كيمياء النوم'],
 [62,72,'المرحلة الأولى','بين اليقظة والنوم','fall','07','بوابة النوم'],
 [72,82,'انتفاضة مفاجئة؟','تجربة شائعة عند بداية النوم','pulse','08','لحظة غريبة'],
 [82,92,'النوم يصبح أعمق','استجابة أقل للأصوات','waves','09','هدوء تدريجي'],
 [92,103,'النوم العميق','إصلاح • تعافٍ • طاقة','cell','10','مرحلة الاستعادة'],
 [103,114,'ذاكرة ومناعة','الجسد يستعيد توازنه','shield','11','إعادة البناء'],
 [114,125,'مرحلة REM','حركة العين السريعة','eye','12','عالم الأحلام'],
 [125,136,'الدماغ نشط… والجسم ساكن','الأحلام تصبح أكثر وضوحًا','dream','13','مفارقة النوم'],
 [136,147,'سر الأحلام','لماذا نرى عوالم لا وجود لها؟','surreal','14','ما الذي نراه؟'],
 [147,158,'ذاكرة • عواطف • تجارب','العلم ما زال يبحث عن الإجابة','memory','15','ترابط الذكريات'],
 [158,169,'لماذا ننسى أحلامنا؟','قد تتلاشى خلال دقائق','fog','16','أثر يتلاشى'],
 [169,180,'النوم يساعدك على التعلّم','المعلومة لا تنتهي بإغلاق الكتاب','book','17','التعلّم والذاكرة'],
 [180,191,'التثبيت يحدث ليلًا','ليلة جيدة قد تصنع فرقًا','synapse','18','شبكات عصبية'],
 [191,202,'ماذا لو حرمت نفسك؟','التعب أول الإشارات','warning','19','ثمن السهر'],
 [202,213,'تركيز أقل • أخطاء أكثر','استجابة أبطأ وانفعال أسرع','focus','20','الأداء اليومي'],
 [213,224,'صحتك تتأثر','القلب • المناعة • الشهية','health','21','الجسم كله'],
 [224,235,'ليست الساعات وحدها','جودة النوم وانتظامه مهمان','quality','22','الجودة أولًا'],
 [235,246,'تنام طويلًا وتستيقظ مرهقًا؟','قد تكون المشكلة في جودة النوم','battery','23','علامة تستحق الانتباه'],
 [246,257,'اضبط ساعتك البيولوجية','موعد ثابت للنوم والاستيقاظ','clock','24','روتين ثابت'],
 [257,268,'خفّف الضوء مساءً','واجعل غرفتك هادئة ومريحة','room','25','تهيئة البيئة'],
 [268,279,'انتبه للكافيين','وضوء النهار والنشاط يساعدان','sun','26','عادات ذكية'],
 [279,290,'كم ساعة تحتاج؟','معظم البالغين: 7 ساعات على الأقل','numbers','27','المدة المناسبة'],
 [290,301,'متى تستشير مختصًا؟','أرق مستمر • شخير شديد • نعاس مفرط','medical','28','لا تتجاهل الإشارات'],
 [301,312,'كل ليلة فرصة جديدة','دماغك وجسمك يعملان من أجلك','brain','29','استعادة التوازن'],
 [312,323,'النوم ليس وقتًا ضائعًا','إنه استثمار في صحتك ومستقبلك','investment','30','استثمار طويل المدى'],
 [323,334,'والآن… سؤال لك','هل تتذكر أحلامك؟','question','31','شاركنا رأيك'],
 [334,344,'أم تختفي بعد لحظات؟','شاركنا إجابتك في التعليقات','comment','32','الحوار مستمر'],
 [344,354.116,'اكتشف المزيد من الأسرار','تابع القناة للمزيد','end','33','Mirror Mirage'],
];
const palettes = [ ['#050A18','#59F0E5','#8B73FF'], ['#080D21','#4FD1FF','#A78BFA'], ['#100A1F','#FFC66D','#FF5C9A'], ['#06121B','#68F0BD','#53A7FF'] ];
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));

function OrbitalArtwork({type, frame, accent, accent2, sceneNo}) {
 const t=frame/FPS; const pulse=1+Math.sin(t*1.25)*.035;
 const common={fill:'none',strokeLinecap:'round',strokeLinejoin:'round'};
 const line=(d, color=accent, width=3, opacity=1)=><path d={d} stroke={color} strokeWidth={width} opacity={opacity} {...common}/>;
 const circle=(cx,cy,r,color=accent,opacity=1,fill='none',width=2)=><circle cx={cx} cy={cy} r={r} stroke={color} strokeWidth={width} opacity={opacity} fill={fill}/>;
 let art;
 switch(type){
 case 'brain': art=<><path d="M205 58c-36-36-86-13-85 25-35 3-54 40-35 68-30 28-14 70 16 80-8 38 23 67 56 53 16 24 42 24 54 5V70c-2-6-4-9-6-12Z" fill={`${accent}22`} stroke={accent} strokeWidth="4"/><path d="M211 58c36-36 86-13 85 25 35 3 54 40 35 68 30 28 14 70-16 80 8 38-23 67-56 53-16 24-42 24-54 5V70" fill={`${accent2}18`} stroke={accent2} strokeWidth="4"/>{line('M210 65v240', '#FFFFFF',2,.7)}{line('M133 104q35-8 42 29t-22 40q-25 19 2 44',accent2,4)}{line('M282 104q-35-8-42 29t22 40q25 19-2 44',accent,4)}{line('M126 215q35-20 48 20t27 20',accent,3)}{line('M294 215q-35-20-48 20t-27 20',accent2,3)}{[ [145,110],[280,125],[170,215],[253,233],[210,164] ].map(([x,y],i)=><g key={i}>{circle(x,y,8,i%2?accent2:accent,.9,i%2?accent2:accent,1)}{circle(x,y,17,i%2?accent2:accent,.3)}</g>)}</>;
 case 'neural': art=<>{Array.from({length:28},(_,i)=>{const x=65+(i*71)%290,y=65+(i*43)%290;const x2=65+((i*71+91)%290),y2=65+((i*43+67)%290);return <g key={i}>{line(`M${x} ${y} L${x2} ${y2}`,i%2?accent:accent2,1.5,.34)}{circle(x,y,i%4===0?6:3,i%2?accent:accent2,.9,i%3===0?accent:'none',1)}</g>})}<circle cx="210" cy="180" r="52" fill={`${accent}16`} stroke={accent} strokeWidth="2"/><text x="210" y="190" textAnchor="middle" fill="#fff" fontSize="26" fontWeight="800">NEURAL</text></>;
 case 'question': art=<>{circle(210,180,110,accent,.5,'none',2)}{circle(210,180,78,accent2,.7,`${accent2}14`,3)}<text x="210" y="218" textAnchor="middle" fontSize="125" fontWeight="900" fill="#fff">؟</text>{line(`M70 285 Q140 ${245+Math.sin(t)*18} 210 285 T350 285`,accent,3,.9)}</>;
 case 'orbit': art=<>{[35,65,95,125].map((r,i)=><g key={r} transform={`rotate(${t*12*(i%2?1:-1)} 210 180)`}>{circle(210,180,r,i%2?accent:accent2,.8,'none',i===3?1.5:2)}<circle cx={210+r} cy="180" r={i%2?5:7} fill={i%2?accent:accent2}/></g>)}<circle cx="210" cy="180" r="23" fill={accent} opacity=".8"/></>;
 case 'moon': art=<>{circle(210,180,118,accent,.4,'none',2)}<path d="M230 65a100 100 0 1 0 85 150A88 88 0 0 1 230 65Z" fill={`${accent}45`} stroke={accent} strokeWidth="3"/>{Array.from({length:24},(_,i)=><g key={i}>{circle(90+(i*61)%240,65+(i*37)%230,i%3===0?3:1.5,i%2?accent2:accent,.65,i%4===0?'#fff':'none',1)}</g>)}</>;
 case 'clock': art=<>{circle(210,180,118,accent,.8,'none',4)}{circle(210,180,92,accent2,.4,'none',1.5)}{Array.from({length:12},(_,i)=><g key={i} transform={`rotate(${i*30} 210 180)`}>{line('M210 75v13','#FFFFFF',3,.8)}</g>)}{line(`M210 180 L210 ${110+Math.sin(t)*7}`,accent,6)}{line(`M210 180 L${260+Math.cos(t)*8} ${210+Math.sin(t)*8}`,accent2,5)}{circle(210,180,7,'#fff',1,'#fff',1)}<text x="210" y="335" textAnchor="middle" fill={accent} fontSize="17" letterSpacing="5">CIRCADIAN RHYTHM</text></>;
 case 'fall': art=<>{Array.from({length:6},(_,i)=><g key={i} transform={`translate(0 ${Math.sin(t+i)*10})`}>{line(`M${90+i*38} 70 Q${65+i*40} 180 ${110+i*35} 285`,i%2?accent:accent2,2,.7)}<circle cx={90+i*38} cy="70" r="5" fill={accent}/></g>)}<path d="M150 130q60-55 120 0l-15 100q-45 40-90 0Z" fill={`${accent2}18`} stroke={accent2} strokeWidth="3"/>{circle(210,180,22,accent,1,`${accent}55`,3)}</>;
 case 'pulse': art=<>{circle(210,180,110,accent,.35,'none',2)}{circle(210,180,78,accent2,.55,'none',2)}{line(`M55 190 H115 L140 150 L167 220 L198 115 L229 242 L253 178 H365`,accent,5)}<circle cx={198} cy="115" r="8" fill="#fff"/><circle cx={198} cy="115" r={15+Math.sin(t*3)*5} fill="none" stroke={accent} strokeWidth="2" opacity=".7"/></>;
 case 'waves': art=<>{Array.from({length:7},(_,i)=><path key={i} d={`M35 ${95+i*30} C95 ${45+i*30},145 ${145+i*30},205 ${95+i*30} S315 ${45+i*30},385 ${95+i*30}`} stroke={i%2?accent:accent2} strokeWidth={i===3?4:2} opacity={.2+i*.09} fill="none" transform={`translate(0 ${Math.sin(t+i*.6)*9})`}/>)}{circle(210,190,25,accent,1,`${accent}40`,3)}</>;
 case 'cell': art=<>{circle(210,180,105,accent,.85,`${accent}10`,3)}{circle(210,180,63,accent2,.8,`${accent2}18`,3)}{circle(210,180,26,'#fff',1,`${accent}50`,2)}{Array.from({length:12},(_,i)=><g key={i} transform={`rotate(${i*30+t*8} 210 180)`}>{line('M210 65v-24',accent,2,.9)}{circle(210,38,5,accent2,1,accent2,1)}</g>)}</>;
 case 'shield': art=<><path d="M210 50 L315 91 V170 Q302 267 210 315 Q118 267 105 170V91Z" fill={`${accent}14`} stroke={accent} strokeWidth="4"/>{line('M155 183l37 38 75-82',accent2,12)}{circle(210,180,135,accent2,.25,'none',1.5)}</>;
 case 'eye': art=<><path d="M45 180 Q210 35 375 180 Q210 325 45 180Z" fill={`${accent}14`} stroke={accent} strokeWidth="4"/>{circle(210,180,65,accent2,.9,`${accent2}44`,3)}{circle(210,180,28,accent,1,accent,1)}{circle(230,160,10,'#fff',1,'#fff',1)}{circle(210,180,88,accent,.3,'none',2)}</>;
 case 'dream': art=<>{circle(210,180,105,accent,.8,`${accent}10`,2)}{circle(170,150,45,accent2,.8,`${accent2}20`,2)}{circle(255,205,34,accent,.9,`${accent}25`,2)}{circle(205,245,18,'#fff',.8,'#fff',1)}{line('M95 250 Q145 210 180 265 T270 265 T335 240',accent2,3,.8)}{Array.from({length:12},(_,i)=><g key={i}>{circle(70+(i*57)%280,60+(i*41)%240,2,i%2?accent:accent2,.8,i%3===0?'#fff':'none',1)}</g>)}</>;
 case 'surreal': art=<>{[0,1,2].map(i=><g key={i} transform={`rotate(${t*9*(i%2?1:-1)} 210 180)`}>{circle(210,180,45+i*38,i%2?accent:accent2,.8,'none',2)}<path d={`M210 ${105-i*20} l12 28 -12 28 -12-28Z`} fill={i%2?accent:accent2} opacity=".7"/></g>)}<path d="M210 70l28 65-28 65-28-65Z" fill={`${accent}45`} stroke={accent} strokeWidth="2"/></>;
 case 'memory': art=<>{Array.from({length:5},(_,i)=><g key={i} transform={`translate(${Math.sin(t+i)*8} ${i*15})`}>{line(`M90 ${85+i*42} C140 ${35+i*42} 175 ${140+i*42} 220 ${85+i*42} S290 ${50+i*42} 330 ${85+i*42}`,i%2?accent:accent2,2.5,.8)}{circle(220,85+i*42,5,accent,1,accent,1)}</g>)}</>;
 case 'fog': art=<>{Array.from({length:8},(_,i)=><ellipse key={i} cx={110+i*28+Math.sin(t+i)*8} cy={100+i*22} rx={95-i*4} ry={25+i%3*5} fill={i%2?accent:accent2} opacity={.035+i*.012}/>) }{circle(210,180,85,accent,.3,'none',2)}<text x="210" y="190" textAnchor="middle" fontSize="40" fill="#fff" opacity={.8}>REM</text></>;
 case 'book': art=<><path d="M70 95 Q145 65 205 105 V285 Q140 250 70 275Z" fill={`${accent}18`} stroke={accent} strokeWidth="3"/><path d="M210 105 Q275 65 350 95 V275 Q280 250 210 285Z" fill={`${accent2}18`} stroke={accent2} strokeWidth="3"/>{[0,1,2,3].map(i=><g key={i}>{line(`M95 ${135+i*32} Q145 ${115+i*32} 185 ${140+i*32}`,accent,2,.65)}{line(`M235 ${140+i*32} Q285 ${115+i*32} 325 ${135+i*32}`,accent2,2,.65)}</g>)}{line('M210 106v179','#fff',2,.7)}</>;
 case 'synapse': art=<>{Array.from({length:9},(_,i)=>{let x=70+i*34,y=90+(i%3)*80+Math.sin(t+i)*12;return <g key={i}>{circle(x,y,9,i%2?accent:accent2,.95,`${i%2?accent:accent2}30`,2)}{i<8&&line(`M${x+9} ${y} Q${x+28} ${y-45} ${x+34} ${90+((i+1)%3)*80+Math.sin(t+i+1)*12}`,accent2,2,.65)}</g>})}<circle cx="210" cy="180" r="115" stroke={accent} strokeWidth="1" strokeDasharray="5 8" fill="none" opacity=".35"/></>;
 case 'warning': art=<><path d="M210 55 L350 295 H70Z" fill={`${accent}16`} stroke={accent} strokeWidth="4"/>{line('M210 125v78','#fff',10)}{circle(210,245,7,'#fff',1,'#fff',1)}{circle(210,180,135,accent2,.3,'none',2)}</>;
 case 'focus': art=<>{[0,1,2,3,4].map(i=><g key={i} transform={`rotate(${i*72+t*4} 210 180)`}>{line('M210 62 L235 105 L210 125 L185 105Z',i%2?accent:accent2,2,.7)}{line('M210 238 L235 255 L210 300 L185 255Z',i%2?accent2:accent,2,.7)}</g>)}{circle(210,180,72,accent,.6,'none',2)}{circle(210,180,30,accent2,1,`${accent2}50`,3)}</>;
 case 'health': art=<><path d="M210 275 C170 240 85 185 105 125 C125 70 185 90 210 130 C235 90 295 70 315 125 C335 185 250 240 210 275Z" fill={`${accent}28`} stroke={accent} strokeWidth="4"/>{line('M85 185h55l22-35 35 70 26-48h90',accent2,4)}{circle(210,180,125,accent2,.2,'none',2)}</>;
 case 'quality': art=<>{circle(210,180,110,accent,.7,'none',3)}{circle(210,180,83,accent2,.6,'none',2)}{circle(210,180,56,accent,.8,`${accent}20`,2)}{line('M160 185l32 32 70-78','#fff',8)}{Array.from({length:4},(_,i)=><g key={i}>{line(`M${90+i*80} 65v-18`,accent2,2,.6)}</g>)}</>;
 case 'battery': art=<><rect x="95" y="120" width="220" height="115" rx="16" fill={`${accent}12`} stroke={accent} strokeWidth="4"/><rect x="315" y="155" width="18" height="45" rx="5" fill={accent}/><rect x="110" y="135" width={Math.max(12,160+Math.sin(t)*22)} height="85" rx="8" fill={accent} opacity=".8"/><path d="M205 145l-30 45h35l-12 32 45-53h-36Z" fill="#fff" opacity=".9"/></>;
 case 'room': art=<><path d="M70 285V140L210 60 350 140V285Z" fill={`${accent}12`} stroke={accent} strokeWidth="3"/><rect x="165" y="190" width="90" height="95" rx="5" fill={`${accent2}22`} stroke={accent2} strokeWidth="3"/><rect x="100" y="155" width="60" height="50" rx="3" fill={`${accent}18`} stroke={accent} strokeWidth="2"/><path d="M100 180h60M130 155v50" stroke={accent} strokeWidth="2"/><path d="M275 120a28 28 0 1 0 28 40 24 24 0 0 1-28-40Z" fill={accent2}/>{[0,1,2,3].map(i=><circle key={i} cx={285+i*13} cy={75+(i%2)*18} r="2.5" fill="#fff" opacity=".8"/>)}</>;
 case 'sun': art=<>{circle(210,165,48,'#FFD166',1,'#FFD166',1)}{Array.from({length:12},(_,i)=><g key={i} transform={`rotate(${i*30+t*4} 210 165)`}>{line('M210 92v-24','#FFD166',4,.9)}</g>)}{line('M55 260 Q130 210 210 260 T365 260',accent,3,.8)}{line('M75 290 Q150 240 230 290 T365 290',accent2,2,.65)}</>;
 case 'numbers': art=<><text x="210" y="205" textAnchor="middle" fill="#fff" fontSize="112" fontWeight="900">7+</text><text x="210" y="248" textAnchor="middle" fill={accent} fontSize="22" letterSpacing="3">HOURS</text>{circle(210,180,130,accent,.45,'none',2)}{circle(210,180,95,accent2,.25,'none',1.5)}</>;
 case 'medical': art=<><rect x="105" y="80" width="210" height="220" rx="16" fill={`${accent}10`} stroke={accent} strokeWidth="3"/><rect x="175" y="130" width="70" height="110" rx="8" fill={`${accent2}22`} stroke={accent2} strokeWidth="3"/><path d="M210 150v70M175 185h70" stroke="#fff" strokeWidth="12" strokeLinecap="round"/>{circle(210,180,135,accent2,.25,'none',2)}</>;
 case 'investment': art=<><path d="M80 280V210h48v70M150 280V170h48v110M220 280V125h48v155M290 280V80h48v200" fill={`${accent}20`} stroke={accent} strokeWidth="3"/>{line('M70 160L145 130 205 145 275 90 340 65',accent2,5)}{line('M320 65h20v20',accent2,4)}</>;
 case 'comment': art=<><path d="M65 90 Q65 65 95 65H325Q355 65 355 95V220Q355 250 325 250H170L105 300V250H95Q65 250 65 220Z" fill={`${accent}14`} stroke={accent} strokeWidth="3"/>{[0,1,2].map(i=><circle key={i} cx={155+i*55} cy="160" r="9" fill={i===1?accent2:accent}/>)}</>;
 case 'end': art=<>{circle(210,180,115,accent,.65,'none',2)}{circle(210,180,85,accent2,.7,'none',2)}{circle(210,180,55,accent,.8,`${accent}25`,2)}<text x="210" y="190" textAnchor="middle" fill="#fff" fontSize="30" fontWeight="900">MM</text>{Array.from({length:18},(_,i)=><g key={i} transform={`rotate(${i*20+t*5} 210 180)`}>{line('M210 45v-15',i%2?accent:accent2,2,.7)}</g>)}</>;
 default: art=<>{circle(210,180,110,accent,.6,'none',2)}{circle(210,180,75,accent2,.6,`${accent2}15`,2)}{line(`M65 205 C120 ${90+Math.sin(t)*18} 170 280 230 155 S315 105 355 190`,accent,4)}{circle(230,155,8,'#fff',1,'#fff',1)}</>;
 }
 return <div style={{position:'absolute',right:'4%',top:'11%',width:'47%',height:'77%',display:'flex',alignItems:'center',justifyContent:'center',transform:`translateY(${Math.sin(t*.8)*8}px) scale(${pulse})`,filter:`drop-shadow(0 0 28px ${accent}30)`}}>
  <div style={{position:'absolute',inset:'3%',border:`1px solid ${accent}28`,borderRadius:24,background:`linear-gradient(135deg,${accent}07,transparent 55%,${accent2}08)`}}/>
  <svg viewBox="0 0 420 360" width="100%" height="100%" style={{overflow:'visible',position:'relative'}}>{art}</svg>
  <div style={{position:'absolute',left:'9%',top:'8%',fontSize:12,letterSpacing:3,color:accent,opacity:.8}}>FIG. {sceneNo} / NEURO LAB</div>
  <div style={{position:'absolute',right:'8%',bottom:'7%',display:'flex',gap:5,alignItems:'end'}}>{Array.from({length:22},(_,i)=><i key={i} style={{display:'block',width:3,height:8+((i*7+Math.floor(t*4))%19),borderRadius:2,background:i%3?accent:accent2,opacity:.35+((i%4)*.15)}}/>)}</div>
 </div>;
}

function Background({frame,accent,accent2}){
 const t=frame/FPS;
 return <AbsoluteFill style={{overflow:'hidden',background:`radial-gradient(ellipse at ${62+Math.sin(t*.17)*8}% ${38+Math.cos(t*.21)*7}%, ${accent}18 0%, transparent 38%), radial-gradient(ellipse at 12% 95%, ${accent2}12 0%, transparent 45%), linear-gradient(125deg,#030711 0%,#071126 52%,#050815 100%)`}}>
  <div style={{position:'absolute',inset:0,opacity:.22,backgroundImage:`linear-gradient(${accent}12 1px,transparent 1px),linear-gradient(90deg,${accent}12 1px,transparent 1px)`,backgroundSize:'64px 64px',transform:`perspective(900px) rotateX(58deg) scale(1.8) translateY(${Math.sin(t*.3)*16}px)`,transformOrigin:'center bottom'}}/>
  {Array.from({length:48},(_,i)=><i key={i} style={{position:'absolute',left:`${(i*47)%100}%`,top:`${(i*31)%100}%`,width:i%8===0?3:1.5,height:i%8===0?3:1.5,borderRadius:'50%',background:i%2?accent:accent2,opacity:.22+(i%5)*.06,transform:`translateY(${Math.sin(t*.7+i)*12}px)`}}/>)}
  <div style={{position:'absolute',left:'-15%',top:'-35%',width:'55%',height:'160%',background:`linear-gradient(90deg,transparent,${accent}08,transparent)`,transform:`rotate(24deg) translateX(${Math.sin(t*.2)*80}px)`}}/>
 </AbsoluteFill>;
}


function CinematicFinish({frame, accent, accent2, sceneNo}) {
 const t = frame / FPS;
 const sweep = (t * 8) % 140 - 20;
 const grain = Array.from({length: 34}, (_, i) => {
   const x = (i * 137 + Math.floor(frame * (i % 3 + 1) / 7) * 17) % 100;
   const y = (i * 71 + Math.floor(frame * (i % 4 + 1) / 11) * 13) % 100;
   return <i key={i} style={{position:'absolute',left:`${x}%`,top:`${y}%`,width:i%7===0?3:1,height:i%7===0?3:1,borderRadius:'50%',background:i%2?accent:accent2,opacity:.12+(i%5)*.035}}/>;
 });
 return <AbsoluteFill style={{pointerEvents:'none',overflow:'hidden'}}>
   {/* anamorphic light sweep */}
   <div style={{position:'absolute',top:'-20%',bottom:'-20%',left:`${sweep}%`,width:'12%',transform:'skewX(-18deg)',background:`linear-gradient(90deg,transparent,${accent}0A,${accent2}12,transparent)`,filter:'blur(14px)'}}/>
   {/* cinematic vignette and soft bloom */}
   <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at 50% 45%, transparent 35%, #02040BE0 100%)'}}/>
   <div style={{position:'absolute',inset:0,background:'linear-gradient(180deg,#02040B55 0%,transparent 18%,transparent 78%,#02040BAA 100%)'}}/>
   {/* subtle film grain particles */}{grain}
   {/* letterbox bars */}
   <div style={{position:'absolute',left:0,right:0,top:0,height:18,background:'#020308B8'}}/>
   <div style={{position:'absolute',left:0,right:0,bottom:0,height:18,background:'#020308B8'}}/>
   {/* tiny scene marker */}
   <div style={{position:'absolute',right:'3.2%',top:'5.2%',display:'flex',alignItems:'center',gap:8,opacity:.6}}>
    <span style={{width:22,height:1,background:accent}}/><span style={{fontSize:10,letterSpacing:3,color:'#fff'}}>MM / {sceneNo}</span>
   </div>
 </AbsoluteFill>;
}

function Scene({data,index,overlap}){
 const frame=useCurrentFrame(); const {fps}=useVideoConfig();
 const [start,end,title,sub,type,num,kicker]=data;
 const duration=(end-start)*fps+(overlap?overlap:0);
 const visualFrame=Math.max(0,frame-overlap);
 const local=visualFrame/fps;
 const [base,accent,accent2]=palettes[index%palettes.length];
 const fadeIn=overlap?interpolate(frame,[0,overlap],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.out(Easing.cubic)}):interpolate(frame,[0,14],[0,1],{extrapolateRight:'clamp'});
 const fadeOut=interpolate(frame,[Math.max(0,duration-14),duration],[1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const opacity=Math.min(fadeIn,fadeOut);
 const enter=interpolate(local,[0,.7],[42,0],{extrapolateRight:'clamp',easing:Easing.out(Easing.cubic)});
 const zoom=interpolate(local,[0,end-start],[1.075,1.015],{extrapolateRight:'clamp'});
 const driftX=Math.sin(local*.24+index*.8)*10;
 const driftY=Math.cos(local*.19+index*.5)*7;
 const progress=clamp(local/Math.max(.1,end-start),0,1);
 return <AbsoluteFill style={{opacity,transform:`translate(${driftX}px,${driftY}px) scale(${zoom})`,fontFamily:'Arial, Tahoma, sans-serif',color:'#fff',overflow:'hidden'}}>
  <Background frame={visualFrame} accent={accent} accent2={accent2}/>
  <OrbitalArtwork type={type} frame={visualFrame} accent={accent} accent2={accent2} sceneNo={num}/>
  <CinematicFinish frame={visualFrame} accent={accent} accent2={accent2} sceneNo={num}/>
  <div style={{position:'absolute',left:'6.2%',top:'11%',width:'44%',height:'76%',borderLeft:`1px solid ${accent}40`,borderTop:`1px solid ${accent}30`,borderBottom:`1px solid ${accent}18`,pointerEvents:'none'}}/>
  <div style={{position:'absolute',left:'8.2%',top:'13.5%',display:'flex',alignItems:'center',gap:13,direction:'ltr'}}>
   <div style={{width:35,height:3,background:accent,boxShadow:`0 0 12px ${accent}`}}/>
   <span style={{fontSize:15,fontWeight:800,letterSpacing:4,color:accent}}>MIRROR MIRAGE</span>
   <span style={{fontSize:12,letterSpacing:2,color:'#ffffff65'}}> / {num}</span>
  </div>
  <div style={{position:'absolute',left:'8.2%',top:'28%',width:'43%',textAlign:'right',direction:'rtl',transform:`translateX(${enter}px)`}}>
   <div style={{display:'inline-flex',alignItems:'center',gap:10,marginBottom:20,padding:'8px 14px',border:`1px solid ${accent}55`,borderRadius:4,background:`${accent}0D`,fontSize:15,fontWeight:800,color:accent,letterSpacing:.5}}>
    <span style={{width:6,height:6,borderRadius:'50%',background:accent,boxShadow:`0 0 10px ${accent}`}}/>{kicker}
   </div>
   <div style={{fontSize:title.length>25?43:title.length>18?49:58,fontWeight:900,lineHeight:1.28,letterSpacing:-1.1,textShadow:`0 5px 28px #0008`,marginBottom:22}}>{title}</div>
   <div style={{width:'100%',height:1,background:`linear-gradient(270deg,${accent},transparent)`,marginBottom:22}}/>
   <div style={{fontSize:26,fontWeight:500,lineHeight:1.65,color:'#DCE7F8',borderRight:`3px solid ${accent}`,paddingRight:17,textShadow:'0 2px 12px #0008'}}>{sub}</div>
   <div style={{display:'flex',justifyContent:'flex-start',gap:8,marginTop:27,direction:'ltr'}}>{[0,1,2,3,4,5].map(i=><div key={i} style={{width:i===Math.floor(progress*6)?27:8,height:4,borderRadius:8,background:i<=Math.floor(progress*6)?accent:'#FFFFFF25',boxShadow:i===Math.floor(progress*6)?`0 0 12px ${accent}`:'none',transition:'width .2s'}}/>)}</div>
  </div>
  <div style={{position:'absolute',left:0,right:0,bottom:0,height:4,background:'#FFFFFF12'}}><div style={{height:'100%',width:`${progress*100}%`,background:`linear-gradient(90deg,${accent2},${accent})`,boxShadow:`0 0 18px ${accent}`}}/></div>
  <div style={{position:'absolute',left:'6.2%',bottom:'4.5%',fontSize:12,letterSpacing:2,color:'#FFFFFF65',direction:'ltr'}}>SLEEP SCIENCE  /  {String(Math.floor(local/60)).padStart(2,'0')}:{String(Math.floor(local%60)).padStart(2,'0')}</div>
  <div style={{position:'absolute',right:'6.2%',bottom:'4.5%',fontSize:12,letterSpacing:2,color:'#FFFFFF65',direction:'ltr'}}>MIND • BODY • MEMORY</div>
 </AbsoluteFill>;
}

function Main(){
 const {fps}=useVideoConfig();
 const overlap=12;
 return <AbsoluteFill style={{background:'#030711'}}>
  <Audio src={staticFile('voice.mp3')} volume={1}/>
  {scenes.map((s,i)=>{
   const start=Math.round(s[0]*fps), end=Math.round(s[1]*fps);
   const from=Math.max(0,start-(i===0?0:overlap));
   const duration=Math.max(1,end-from);
   return <Sequence key={s[5]} from={from} durationInFrames={duration} premountFor={fps}>
    <Scene data={s} index={i} overlap={i===0?0:overlap}/>
   </Sequence>;
  })}
 </AbsoluteFill>;
}
function Root(){return <Composition id="SleepMotion" component={Main} durationInFrames={Math.ceil(DURATION*FPS)} fps={FPS} width={1920} height={1080}/>;}
registerRoot(Root);
